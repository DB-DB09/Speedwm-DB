#!/bin/bash

# Set wallpaper
feh --bg-scale /home/db/Pictures/dark_mountains.png
