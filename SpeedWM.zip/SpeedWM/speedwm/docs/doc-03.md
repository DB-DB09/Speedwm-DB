## 3. Layouts

speedwm comes with the following layouts:

  - Tile
  - Monocle
  - Grid
  - Deck
  - Centered Master
  - Tatami
  - Spiral
  - Dwindle
  - Bottom Stack
  - Horizontal Bottom Stack
  - Horizonal Grid
  - Dynamic Grid
  - Custom
  - Empty

They can be switched between using a little menu (See Keybinds for more information) or by right clicking the Layout indicator.
The more commonly used layouts can be switched between using a quick keybind.

