### **speedwm 1.9**

### Changelog
- Version bump

### Installation
Nothing has changed with the installation since last release, simply download and unpack the tarball, and `make clean install` as root.

- If you are on Gentoo, you can install x11-wm/speedwm, x11-wm/libspeedwm and x11-wm/speedwm-extras by adding my overlay.
- I plan on writing an Arch AUR package eventually, but please feel free to do my job ;)
