## Credits

I far from wrote this entire project myself. Below are people who made this project what it is through submitting patches to suckless or otherwise contributing code in some way in alphabetical order.

- Adam Yuan
- Alex Cole
- Anukul Adhikari
- Ayoub Khater
- bakkeby
- bit6tream
- cd
- Chris Down
- Chris Noxz
- Daniel Bylinka
- Dhaval Patel
- Eon S. Jeon
- explosion-mental
- Fabian Blatz
- Finn Rayment
- Georgios Oxinos
- Ivan J.
- Jan Christoph Ebersbach
- Jared
- kleinbottle4
- Luigi Foscari
- Luke Smith
- Marius Iacob
- Markus Teich
- Mihir Lad
- MLquest8
- Ondřej Grover
- ornx
- Patrick Steinhardt
- phi
- prx
- Rob King
- Ryan Roden-Corrent
- sipi
- Sönke Lambert
- speedie
- Stefan Mark
- Stefan Matz
- suckless.org
- Timmy Keller
- Viliam Kováč

See Codeberg contributions for more information.
