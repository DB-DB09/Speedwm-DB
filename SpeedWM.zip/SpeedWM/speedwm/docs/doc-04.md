## 4. Default keybinds

This is a full list of keybinds.
Please let me know if any keybinds are missing as these have been manually added.

