#include "../toggle.h" /* Include what we've included */

#include "tags-powerline.c" /* Include powerline tags */
#include "tags.c" /* Include tags */
#include "layoutindicator.c" /* Include layout indicator */
#include "statusbar.c" /* Include status bar with status2d and clickstatus */
#include "statusbar-es.c" /* Include status bar with status2d and clickstatus */
#include "statusbar-basic.c" /* Include basic status bar */
#include "statusbar-basic-es.c" /* Include basic status bar */
#include "statusbar-powerline.c" /* Include powerline status bar */
#include "statusbar-powerline-es.c" /* Include powerline status bar */
#include "title-basic.c" /* Include basic title */
#include "title.c" /* Include title */
#include "systray.c" /* Include systray */
