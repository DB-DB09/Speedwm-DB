static int width_title(Bar *bar, BarWidthArg *a);
static int draw_title(Bar *bar, BarDrawArg *a);
static int click_title(Bar *bar, Arg *arg, BarClickArg *a);
