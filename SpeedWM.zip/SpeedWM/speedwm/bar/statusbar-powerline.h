static int width_status_pwl(Bar *bar, BarWidthArg *a);
static int draw_status_pwl(Bar *bar, BarDrawArg *a);
static int click_status_pwl(Bar *bar, Arg *arg, BarClickArg *a);
static int drawpowerlinestatus(int x, char *stext);
static int widthpowerlinestatus(char *stext);
