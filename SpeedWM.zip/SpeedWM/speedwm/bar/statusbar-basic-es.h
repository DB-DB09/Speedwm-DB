static int width_status_basic_es(Bar *bar, BarWidthArg *a);
static int draw_status_basic_es(Bar *bar, BarDrawArg *a);
static int click_status_basic_es(Bar *bar, Arg *arg, BarClickArg *a);
