static int width_title_basic(Bar *bar, BarWidthArg *a);
static int draw_title_basic(Bar *bar, BarDrawArg *a);
static int click_title_basic(Bar *bar, Arg *arg, BarClickArg *a);
