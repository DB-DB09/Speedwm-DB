static int width_tags_pwl(Bar *bar, BarWidthArg *a);
static int draw_tags_pwl(Bar *bar, BarDrawArg *a);
static int click_tags_pwl(Bar *bar, Arg *arg, BarClickArg *a);
