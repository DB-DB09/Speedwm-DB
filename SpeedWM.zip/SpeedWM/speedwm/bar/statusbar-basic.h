static int width_status_basic(Bar *bar, BarWidthArg *a);
static int draw_status_basic(Bar *bar, BarDrawArg *a);
static int click_status_basic(Bar *bar, Arg *arg, BarClickArg *a);
