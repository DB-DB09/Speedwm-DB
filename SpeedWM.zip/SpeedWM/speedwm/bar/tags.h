static int width_tags(Bar *bar, BarWidthArg *a);
static int draw_tags(Bar *bar, BarDrawArg *a);
static int click_tags(Bar *bar, Arg *arg, BarClickArg *a);
