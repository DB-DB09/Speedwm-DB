/* These are all your keybinds.
 *
 * Event
 *
 * KeyPress - Activate when a key is pressed.
 * KeyRelease - Activate when a key is released.
 *
 * Modifiers
 *
 * MODIFIER1 is what you defined below, default is Super)
 * MODIFIER2 is what you defined below, default is Alt)
 * SHIFT is unless changed going to be your Shift key.
 * CONTROL is unless changed going to be your Control key.
 * ALT unless changed is going to be your left Alt key.
 * ALTR unless changed is going to be your right Alt key.
 * SUPER unless changed is going to be your left Super (Windows/macOS Command) key.
 * SUPERR unless changed is going to be your right Super (Windows/macOS Command) key.
 *
 * Example keybind:
 *
 * { KeyPress,   MODIFIER1, -1, XK_1, spawn, cmd( TERMINAL "echo 'Hello world!' ) },
 * { KeyRelease, MODIFIER1, XK_F1, XK_1, spawn, cmd( TERMINAL "echo 'Hello world! Pressing two keys in a row is based!' ) },
 *
 * It is recommended that you avoid using 'MODIFIER2' (Mod1Mask) by itself because it can break software defined shortcuts.
 *
 * If you need help, see the man page for speedwm.
 * Once you're done with your edits, run 'make clean install'.
 */

/* These are all your keybinds.
 * Converted from Hyprland configuration to SpeedWM format
 * Original Hyprland configs by JaKooLit (https://github.com/JaKooLit)
 */

/* For terminal keybinds */
#define TERMINAL "kitty "
#define Thunar "thunar "
#define SCRIPTS_DIR "~/.config/hypr/scripts"
#define USER_SCRIPTS "~/.config/hypr/UserScripts"

#include <X11/XF86keysym.h>

#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* Modifier keys
 * Mod4Mask | Super (Windows/command) key
 * Mod1Mask | Alt key
 */
#define MODIFIER1 Mod4Mask
#define MODIFIER2 Mod1Mask

/* Tag related keybinds */
#define TAGKEYS(CHAIN,KEY,TAG) { KeyPress,      MODIFIER1,                   CHAIN, KEY, view,       {.ui = 1 << TAG } },  \
                               { KeyPress,      MODIFIER1|SHIFT,             CHAIN, KEY, previewtag, {.ui = TAG      } },  \
							   { KeyPress,      MODIFIER1|CONTROL,           CHAIN, KEY, toggleview, {.ui = 1 << TAG } },  \
							   { KeyPress,      MODIFIER1|SHIFT|CONTROL,     CHAIN, KEY, tag,        {.ui = 1 << TAG } },

/* Keybinds */
static Key keys[] = {
	/* type          modifier                     chain key      key           function              argument */
	
	/* Basic window management */
	{ KeyPress,      MODIFIER1,                   -1,            XK_q,         killclient,           {0} }, /* close active window */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_q,         spawn,                cmd( SCRIPTS_DIR "/KillActiveProcess.sh" ) }, /* kill active process */
	{ KeyPress,      MODIFIER1,                   -1,            XK_f,         togglefullscr,        {0} }, /* toggle full screen */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_f,         togglefullscr,        {0} }, /* fake full screen */
	{ KeyPress,      MODIFIER1,                   -1,            XK_space,     togglefloating,       {0} }, /* toggle floating */
	
	/* Applications */
	{ KeyPress,      MODIFIER1,                   -1,            XK_d,         spawn,                cmd( "pkill rofi || true && rofi -show drun -modi drun,filebrowser,run,window" ) }, /* app launcher */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Return,    spawn,                cmd( TERMINAL ) }, /* terminal */
	{ KeyPress,      MODIFIER1,                   -1,            XK_t,         spawn,                cmd( Thunar ) }, /* file manager */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Return,    spawn,                cmd( TERMINAL " -f" ) }, /* floating terminal */
	{ KeyPress,      MODIFIER1,                   -1,            XK_l,         spawn,                cmd( SCRIPTS_DIR "/LockScreen.sh" ) }, /* lock screen */
	
	/* Screenshots */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --now" ) }, /* screenshot */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --area" ) }, /* screenshot area */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --in5" ) }, /* screenshot delay 5s */
	{ KeyPress,      MODIFIER1|CONTROL|SHIFT,     -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --in10" ) }, /* screenshot delay 10s */
	{ KeyPress,      MODIFIER2,                   -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --active" ) }, /* screenshot active window */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_s,         spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --swappy" ) }, /* screenshot swappy */
	
	/* Main Menu Hyprland Features */
	{ KeyPress,      MODIFIER1,                   -1,            XK_h,         spawn,                cmd( SCRIPTS_DIR "/KeyHints.sh" ) }, /* help */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_g,         spawn,                cmd( SCRIPTS_DIR "/GameMode.sh" ) }, /* game mode */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_n,         spawn,                cmd( "swaync-client -t -sw" ) }, /* notification panel */
	{ KeyPress,      MODIFIER1,                   -1,            XK_e,         spawn,                cmd( SCRIPTS_DIR "/Kool_Quick_Settings.sh" ) }, /* settings menu */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_k,         spawn,                cmd( SCRIPTS_DIR "/KeyBinds.sh" ) }, /* keybinds */
	
	/* Window focus and movement */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Left,      focusstackvis,        {.i = -1 } }, /* focus left */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Right,     focusstackvis,        {.i = +1 } }, /* focus right */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Up,        focusstackvis,        {.i = -1 } }, /* focus up */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Down,      focusstackvis,        {.i = +1 } }, /* focus down */
	
	/* Swap windows (equivalent to Hyprland's swapwindow) */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_Left,      inplacerotate,        {.i = -1} }, /* swap with window to the left */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_Right,     inplacerotate,        {.i = +1} }, /* swap with window to the right */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_Up,        inplacerotate,        {.i = -2} }, /* swap with window above */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_Down,      inplacerotate,        {.i = +2} }, /* swap with window below */
	
	/* Move windows (equivalent to Hyprland's movewindow) */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Left,      moveresize,           {.v = "-25x 0y 0w 0h" } }, /* move window left */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Right,     moveresize,           {.v = "25x 0y 0w 0h" } }, /* move window right */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Up,        moveresize,           {.v = "0x -25y 0w 0h" } }, /* move window up */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Down,      moveresize,           {.v = "0x 25y 0w 0h" } }, /* move window down */
	
	/* Resize windows */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Left,      moveresize,           {.v = "0x 0y -25w 0h" } }, /* resize left */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Right,     moveresize,           {.v = "0x 0y 25w 0h" } }, /* resize right */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Up,        moveresize,           {.v = "0x 0y 0w -25h" } }, /* resize up */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Down,      moveresize,           {.v = "0x 0y 0w 25h" } }, /* resize down */
	
	/* Master layout commands (equivalent to Hyprland's layoutmsg) */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_d,         incmastercount,       {.i = -1 } }, /* remove master */
	{ KeyPress,      MODIFIER1,                   -1,            XK_i,         incmastercount,       {.i = +1 } }, /* add master */
	{ KeyPress,      MODIFIER1,                   -1,            XK_j,         focusstackvis,        {.i = +1 } }, /* cycle next */
	{ KeyPress,      MODIFIER1,                   -1,            XK_k,         focusstackvis,        {.i = -1 } }, /* cycle prev */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Return,    zoom,                 {0} }, /* swap with master */
	
	/* Layouts and layout options */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_l,         spawn,                cmd( SCRIPTS_DIR "/ChangeLayout.sh" ) }, /* toggle layouts */
	
	/* Workspace management */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Tab,       viewtoright,          {0} }, /* next workspace */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Tab,       viewtoleft,           {0} }, /* prev workspace */
	{ KeyPress,      MODIFIER1,                   -1,            XK_period,    viewtoright,          {0} }, /* next workspace */
	{ KeyPress,      MODIFIER1,                   -1,            XK_comma,     viewtoleft,           {0} }, /* prev workspace */
	
	/* Special workspace (scratchpad in speedwm) */
	{ KeyPress,      MODIFIER1,                   -1,            XK_u,         scratchpad_show,      {0} }, /* show scratchpad */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_u,         scratchpad_hide,      {0} }, /* move to scratchpad */
	
	/* Media and volume keys (using scripts like Hyprland) */
	{ KeyPress,      0,                           -1,            XF86XK_AudioRaiseVolume, spawn,     cmd( SCRIPTS_DIR "/Volume.sh --inc" ) }, /* volume up */
	{ KeyPress,      0,                           -1,            XF86XK_AudioLowerVolume, spawn,     cmd( SCRIPTS_DIR "/Volume.sh --dec" ) }, /* volume down */
	{ KeyPress,      0,                           -1,            XF86XK_AudioMute, spawn,            cmd( SCRIPTS_DIR "/Volume.sh --toggle" ) }, /* mute */
	{ KeyPress,      0,                           -1,            XF86XK_AudioMicMute, spawn,         cmd( SCRIPTS_DIR "/Volume.sh --toggle-mic" ) }, /* mic mute */
	{ KeyPress,      0,                           -1,            XF86XK_AudioPlay, spawn,            cmd( SCRIPTS_DIR "/MediaCtrl.sh --pause" ) }, /* play/pause */
	{ KeyPress,      0,                           -1,            XF86XK_AudioNext, spawn,            cmd( SCRIPTS_DIR "/MediaCtrl.sh --nxt" ) }, /* next */
	{ KeyPress,      0,                           -1,            XF86XK_AudioPrev, spawn,            cmd( SCRIPTS_DIR "/MediaCtrl.sh --prv" ) }, /* previous */
	{ KeyPress, 	 0,                        	  -1, 			 XF86XK_MonBrightnessUp,    spawn,   cmd( SCRIPTS_DIR "/Brightness.sh -inc 5") },
	{ KeyPress, 	 0,                    		  -1,    		 XF86XK_MonBrightnessDown,  spawn,   cmd( SCRIPTS_DIR "/Brightness.sh -dec 5") },
	
	/* Custom Hyprland shortcuts */
	{ KeyPress,      MODIFIER1,                   -1,            XK_w,         spawn,                cmd( USER_SCRIPTS "/WallpaperSelect.sh" ) }, /* wallpaper select */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_w,         spawn,                cmd( USER_SCRIPTS "/WallpaperEffects.sh" ) }, /* wallpaper effects */
	{ KeyPress,      CONTROL|MODIFIER2,           -1,            XK_w,         spawn,                cmd( USER_SCRIPTS "/WallpaperRandom.sh" ) }, /* random wallpaper */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_m,         spawn,                cmd( USER_SCRIPTS "/RofiBeats.sh" ) }, /* rofi beats */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_a,         spawn,                cmd( SCRIPTS_DIR "/Animations.sh" ) }, /* animations */
	
	/* Toggle opacity */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_o,         toggleopacity,        {0} }, /* toggle opacity */
	
	/* Exit Hyprland equivalent */
	{ KeyPress,      CONTROL|MODIFIER2,           -1,            XK_Delete,    quit,                 {0} }, /* exit speedwm */
	
	/* Power menu */
	{ KeyPress,      MODIFIER2,                   -1,            XK_F4,        spawn,                cmd( SCRIPTS_DIR "/Wlogout.sh" ) }, /* power menu */
	
	/* Tag keybinds (workspaces) */
	TAGKEYS(                                      -1,            XK_1,         0)
	TAGKEYS(                                      -1,            XK_2,         1)
	TAGKEYS(                                      -1,            XK_3,         2)
	TAGKEYS(                                      -1,            XK_4,         3)
	TAGKEYS(                                      -1,            XK_5,         4)
	TAGKEYS(                                      -1,            XK_6,         5)
	TAGKEYS(                                      -1,            XK_7,         6)
	TAGKEYS(                                      -1,            XK_8,         7)
	TAGKEYS(                                      -1,            XK_9,         8)
	TAGKEYS(                                      -1,            XK_0,         9)

	/* Group management (similar to Hyprland groups) */
	{ KeyPress,      MODIFIER1,                   -1,            XK_g,         togglemark,           {0} }, /* toggle group/mark */

	/* Waybar/Bar related */
	{ KeyPress,      MODIFIER1,                   -1,            XK_b,         togglebar,            {0} }, /* toggle bar */
};