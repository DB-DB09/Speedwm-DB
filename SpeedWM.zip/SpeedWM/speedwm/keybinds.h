/* These are all your keybinds.
 *
 * Event
 *
 * KeyPress - Activate when a key is pressed.
 * KeyRelease - Activate when a key is released.
 *
 * Modifiers
 *
 * MODIFIER1 is what you defined below, default is Super)
 * MODIFIER2 is what you defined below, default is Alt)
 * SHIFT is unless changed going to be your Shift key.
 * CONTROL is unless changed going to be your Control key.
 * ALT unless changed is going to be your left Alt key.
 * ALTR unless changed is going to be your right Alt key.
 * SUPER unless changed is going to be your left Super (Windows/macOS Command) key.
 * SUPERR unless changed is going to be your right Super (Windows/macOS Command) key.
 *
 * Example keybind:
 *
 * { KeyPress,   MODIFIER1, -1, XK_1, spawn, cmd( TERMINAL "echo 'Hello world!' ) },
 * { KeyRelease, MODIFIER1, XK_F1, XK_1, spawn, cmd( TERMINAL "echo 'Hello world! Pressing two keys in a row is based!' ) },
 *
 * It is recommended that you avoid using 'MODIFIER2' (Mod1Mask) by itself because it can break software defined shortcuts.
 *
 * If you need help, see the man page for speedwm.
 * Once you're done with your edits, run 'make clean install'.
 */

/* These are all your keybinds.
 * Converted from Hyprland configuration to SpeedWM format
 * Original Hyprland configs by JaKooLit (https://github.com/JaKooLit)
 */

/* For terminal keybinds */
#include <X11/XF86keysym.h>
#define TERMINAL "kitty "
#define Thunar "thunar "
#define SCRIPTS_DIR "~/.config/hypr/scripts"
#define USER_SCRIPTS "~/.config/hypr/UserScripts"

/* Modifier keys
 * Mod4Mask | Super (Windows/command) key
 * Mod1Mask | Alt key
 */
#define MODIFIER1 Mod4Mask
#define MODIFIER2 Mod1Mask

/* Tag related keybinds */
#define TAGKEYS(CHAIN,KEY,TAG) { KeyPress,      MODIFIER1,                   CHAIN, KEY, view,       {.ui = 1 << TAG } },  \
                               { KeyPress,      MODIFIER1|SHIFT,             CHAIN, KEY, previewtag, {.ui = TAG      } },  \
							   { KeyPress,      MODIFIER1|CONTROL,           CHAIN, KEY, toggleview, {.ui = 1 << TAG } },  \
							   { KeyPress,      MODIFIER1|SHIFT|CONTROL,     CHAIN, KEY, tag,        {.ui = 1 << TAG } },

/* helper for spawning shell commands in the pre dwm-5.0 fashion */
#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* Keybinds */
static Key keys[] = {
	/* type          modifier                     chain key      key           function              argument */
	
	/* Basic window management */
	{ KeyPress,      MODIFIER1,                   -1,            XK_q,         killclient,           {0} }, /* close active window */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_q,         spawn,                cmd( SCRIPTS_DIR "/KillActiveProcess.sh" ) }, /* kill active process */
	{ KeyPress,      MODIFIER1,                   -1,            XK_f,         togglefullscr,        {0} }, /* toggle full screen */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_f,         togglefullscr,        {0} }, /* fake full screen */
	{ KeyPress,      MODIFIER1,                   -1,            XK_space,     togglefloating,       {0} }, /* toggle floating */
	
	/* Applications */
	{ KeyPress,      MODIFIER1,                   -1,            XK_d,         spawn,                cmd( "pkill rofi || true && rofi -show drun -modi drun,filebrowser,run,window" ) }, /* app launcher */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Return,    spawn,                cmd( TERMINAL ) }, /* terminal */
	{ KeyPress,      MODIFIER1,                   -1,            XK_t,         spawn,                cmd( Thunar ) }, /* file manager */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Return,    spawn,                cmd( TERMINAL " -f" ) }, /* floating terminal */
	{ KeyPress,      MODIFIER1,                   -1,            XK_l,         spawn,                cmd( SCRIPTS_DIR "/LockScreen.sh" ) }, /* lock screen */
	
	/* Screenshots */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --now" ) }, /* screenshot */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --area" ) }, /* screenshot area */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --in5" ) }, /* screenshot delay 5s */
	{ KeyPress,      MODIFIER1|CONTROL|SHIFT,     -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --in10" ) }, /* screenshot delay 10s */
	{ KeyPress,      MODIFIER2,                   -1,            XK_Print,     spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --active" ) }, /* screenshot active window */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_s,         spawn,                cmd( SCRIPTS_DIR "/ScreenShot.sh --swappy" ) }, /* screenshot swappy */
	
	/* Window focus and movement */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Left,      focusstackvis,        {.i = -1 } }, /* focus left */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Right,     focusstackvis,        {.i = +1 } }, /* focus right */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Up,        focusstackvis,        {.i = -1 } }, /* focus up */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Down,      focusstackvis,        {.i = +1 } }, /* focus down */
	
	/* Swap windows (equivalent to Hyprland's swapwindow) */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_Left,      inplacerotate,        {.i = -1} }, /* swap with window to the left */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_Right,     inplacerotate,        {.i = +1} }, /* swap with window to the right */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_Up,        inplacerotate,        {.i = -2} }, /* swap with window above */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_Down,      inplacerotate,        {.i = +2} }, /* swap with window below */
	
	/* Move windows (equivalent to Hyprland's movewindow) */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Left,      moveresize,           {.v = "-25x 0y 0w 0h" } }, /* move window left */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Right,     moveresize,           {.v = "25x 0y 0w 0h" } }, /* move window right */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Up,        moveresize,           {.v = "0x -25y 0w 0h" } }, /* move window up */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Down,      moveresize,           {.v = "0x 25y 0w 0h" } }, /* move window down */
	
	/* Resize windows */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Left,      moveresize,           {.v = "0x 0y -25w 0h" } }, /* resize left */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Right,     moveresize,           {.v = "0x 0y 25w 0h" } }, /* resize right */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Up,        moveresize,           {.v = "0x 0y 0w -25h" } }, /* resize up */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Down,      moveresize,           {.v = "0x 0y 0w 25h" } }, /* resize down */
	
	/* Master layout commands (equivalent to Hyprland's layoutmsg) */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_d,         incmastercount,       {.i = -1 } }, /* remove master */
	{ KeyPress,      MODIFIER1,                   -1,            XK_i,         incmastercount,       {.i = +1 } }, /* add master */
	{ KeyPress,      MODIFIER1,                   -1,            XK_j,         focusstackvis,        {.i = +1 } }, /* cycle next */
	{ KeyPress,      MODIFIER1,                   -1,            XK_k,         focusstackvis,        {.i = -1 } }, /* cycle prev */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_Return,    zoom,                 {0} }, /* swap with master */
	
	/* Layouts and layout options */
	{ KeyPress,      MODIFIER1|MODIFIER2,         -1,            XK_l,         spawn,                cmd( SCRIPTS_DIR "/ChangeLayout.sh" ) }, /* toggle layouts */
	
	/* Workspace management */
	{ KeyPress,      MODIFIER1,                   -1,            XK_Tab,       viewtoright,          {0} }, /* next workspace */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_Tab,       viewtoleft,           {0} }, /* prev workspace */
	{ KeyPress,      MODIFIER1,                   -1,            XK_period,    viewtoright,          {0} }, /* next workspace */
	{ KeyPress,      MODIFIER1,                   -1,            XK_comma,     viewtoleft,           {0} }, /* prev workspace */
	
	/* Special workspace (scratchpad in speedwm) */
	{ KeyPress,      MODIFIER1,                   -1,            XK_u,         scratchpad_show,      {0} }, /* show scratchpad */
	{ KeyPress,      MODIFIER1|SHIFT,             -1,            XK_u,         scratchpad_hide,      {0} }, /* move to scratchpad */
	
    /* Multimedia keys */
    { KeyPress,      0,                           -1,            XF86XK_AudioLowerVolume,   spawn,   {.v = (const char*[]){ "/bin/sh", "-c", "amixer sset Master 5%- unmute", NULL } } },
    { KeyPress,      0,                           -1,            XF86XK_AudioMute,          spawn,   {.v = (const char*[]){ "/bin/sh", "-c", "amixer sset Master $(amixer get Master | grep -q '\\[on\\]' && echo 'mute' || echo 'unmute')", NULL } } },
    { KeyPress,      0,                           -1,            XF86XK_AudioRaiseVolume,   spawn,   {.v = (const char*[]){ "/bin/sh", "-c", "amixer sset Master 5%+ unmute", NULL } } },
	{ KeyPress, 	 0,							  -1, 			 XF86XK_MonBrightnessUp,    spawn,	 {.v = light_up}},
	{ KeyPress, 	 0,							  -1,			 XF86XK_MonBrightnessDown,  spawn,	 {.v = light_down}},
	
	/* Toggle opacity */
	{ KeyPress,      MODIFIER1|CONTROL,           -1,            XK_o,         toggleopacity,        {0} }, /* toggle opacity */
	
	/* Exit Hyprland equivalent */
	{ KeyPress,      CONTROL|MODIFIER2,           -1,            XK_Delete,    quit,                 {0} }, /* exit speedwm */
	
	/* Power menu */
	{ KeyPress,      MODIFIER2,                   -1,            XK_F4,        spawn,                cmd( SCRIPTS_DIR "/Wlogout.sh" ) }, /* power menu */
	
	/* Tag keybinds (workspaces) */
	TAGKEYS(                                      -1,            XK_1,         0)
	TAGKEYS(                                      -1,            XK_2,         1)
	TAGKEYS(                                      -1,            XK_3,         2)
	TAGKEYS(                                      -1,            XK_4,         3)
	TAGKEYS(                                      -1,            XK_5,         4)
	TAGKEYS(                                      -1,            XK_6,         5)
	TAGKEYS(                                      -1,            XK_7,         6)
	TAGKEYS(                                      -1,            XK_8,         7)
	TAGKEYS(                                      -1,            XK_9,         8)
	TAGKEYS(                                      -1,            XK_0,         9)

	/* Group management (similar to Hyprland groups) */
	{ KeyPress,      MODIFIER1,                   -1,            XK_g,         togglemark,           {0} }, /* toggle group/mark */

	/* Waybar/Bar related */
	{ KeyPress,      MODIFIER1,                   -1,            XK_b,         togglebar,            {0} }, /* toggle bar */
};