static void readstdin(void);
