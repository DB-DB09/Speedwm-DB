static void create_window(int x, int y, int w, int h);
static void prepare_window_size(void);
static void set_window(void);
static void set_prop(void);
static void resizeclient(void);
