static void conf_init(void);
