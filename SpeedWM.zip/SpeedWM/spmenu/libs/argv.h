static void readargs(int argc, char *argv[]);
static void usage(void);
