static void fuzzymatch(void);
static void match(void);
static int compare_distance(const void *a, const void *b);
