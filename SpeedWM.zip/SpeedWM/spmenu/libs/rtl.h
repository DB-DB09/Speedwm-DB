static char fribidi_text[BUFSIZ] = "";
static void apply_fribidi(char *str);
