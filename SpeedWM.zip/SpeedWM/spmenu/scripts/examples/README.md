# spmenu example scripts

This folder contains spmenu example scripts which may be used to learn how to do certain things in spmenu. They are not installed automatically, but feel free to copy the scripts somewhere and use them to learn.
